-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 15, 2016 at 11:59 AM
-- Server version: 5.5.47-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `gallery`
--

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE IF NOT EXISTS `images` (
  `id_img` int(11) NOT NULL AUTO_INCREMENT,
  `img_path` varchar(100) NOT NULL,
  `thumbs_path` varchar(120) NOT NULL,
  `img_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_img`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id_img`, `img_path`, `thumbs_path`, `img_count`) VALUES
(1, 'img/doroga.jpg', 'img/thumbs/doroga.jpg', 15),
(2, 'img/raduga.jpg', 'img/thumbs/raduga.jpg', 21),
(3, 'img/275301-frederika.jpg', 'img/thumbs/275301-frederika.jpg', 7),
(4, 'img/399273_priroda_leto_derevya_trava_zelen_2048x1365_www.GdeFon.ru_.jpg', 'img/thumbs/399273_priroda_leto_derevya_trava_zelen_2048x1365_www.GdeFon.ru_.jpg', 2),
(5, 'img/10095010-R3L8T8D-1000-797ab841d30ecf2e893c6ff55e0e067a_970x.jpg', 'img/thumbs/10095010-R3L8T8D-1000-797ab841d30ecf2e893c6ff55e0e067a_970x.jpg', 39),
(6, 'img/c392c3f3.jpg', 'img/thumbs/c392c3f3.jpg', 5),
(7, 'img/forest.jpg', 'img/thumbs/forest.jpg', 0),
(8, 'img/oboi_priroda_943087.jpg', 'img/thumbs/oboi_priroda_943087.jpg', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
